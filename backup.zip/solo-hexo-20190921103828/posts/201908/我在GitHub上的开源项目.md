title: 我在 GitHub 上的开源项目
date: '2019-08-14 10:28:26'
updated: '2019-08-14 10:28:26'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [joine](https://github.com/jenphyjohn/joine) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/jenphyjohn/joine/watchers "关注数")&nbsp;&nbsp;[⭐️`4`](https://github.com/jenphyjohn/joine/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/jenphyjohn/joine/network/members "分叉数")</span>

Joine基础管理系统-基于SpringBoot2.0



---

### 2. [joine-server](https://github.com/jenphyjohn/joine-server) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/jenphyjohn/joine-server/watchers "关注数")&nbsp;&nbsp;[⭐️`2`](https://github.com/jenphyjohn/joine-server/stargazers "收藏数")&nbsp;&nbsp;[🖖`2`](https://github.com/jenphyjohn/joine-server/network/members "分叉数")</span>

基于Spring Cloud微服务服务端框架



---

### 3. [joine-ui](https://github.com/jenphyjohn/joine-ui) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/jenphyjohn/joine-ui/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/jenphyjohn/joine-ui/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/jenphyjohn/joine-ui/network/members "分叉数")</span>

joine-server配套的前端页面



---

### 4. [solo-blog](https://github.com/jenphyjohn/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/jenphyjohn/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/jenphyjohn/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/jenphyjohn/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`http://blog.join-e.tech`](http://blog.join-e.tech "项目主页")</span>

木鱼酱 - 记录精彩的程序人生



---

### 5. [springboot-swagger-rest-demo](https://github.com/jenphyjohn/springboot-swagger-rest-demo) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/jenphyjohn/springboot-swagger-rest-demo/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/jenphyjohn/springboot-swagger-rest-demo/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/jenphyjohn/springboot-swagger-rest-demo/network/members "分叉数")</span>

springboot-swagger-rest-demo

