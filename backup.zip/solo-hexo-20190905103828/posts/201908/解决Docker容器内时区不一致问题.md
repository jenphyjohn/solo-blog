title: 解决Docker容器内时区不一致问题
date: '2019-08-17 23:32:21'
updated: '2019-08-30 13:51:05'
tags: [docker, K8S]
permalink: /articles/2019/08/17/1566055941127.html
---
![](https://img.hacpai.com/bing/20180818.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 问题描述

joine-admin模块部署在K8S上，通过查看日志发现，时间晚了8小时，遂猜想是时区问题。

### 排查问题

#### 操作记录：

1. 查看k8s指定命名空间下启动的容器

```
kubectl get po -n mynamespace
```
2. 查看指定容器日志
```
kubectl logs -f --tail=200 -n mynamespace mycontainername
```
![8F41B1594606BE43EA40AB8682B1CEC1.jpg](https://img.hacpai.com/file/2019/08/8F41B1594606BE43EA40AB8682B1CEC1-5aa462f4.jpg)

### 解决问题

#### 操作记录：

1. 首先，进入容器内查看系统时间，判断日期是否正确。
```
kubectl exec -it mycontainername -n mycoach -- /bin/sh
```
```
/ # date
Sun Aug 18 09:29:17 UTC 2019
```
可以看到，这里的时区并不是东八区，找到问题根源
> CST应该是指（China Shanghai Time，东八区时间） 
> UTC应该是指（Coordinated Universal Time，标准时间）

2. 为了解决容器内时区问题，我们需要修改系统两处文件：`/etc/localtime` 和 `/etc/timezone`

3. 为了减少操作，自动化执行，此处我们采用修改Dockerfile的方式
* ###### 修改前
```
FROM java:8 
ADD target/Joine.jar /app.jar
EXPOSE 8080
ENTRYPOINT ["java","-jar","/app.jar"]
```
* ###### 修改后
```
FROM java:8
RUN ln -sf /usr/share/zoneinfo/Asia/Shanghai /etc/localtime \
	&& echo 'Asia/Shanghai' >/etc/timezone
ADD target/Joine.jar /app.jar
EXPOSE 8080
ENTRYPOINT ["java","-jar","/app.jar"]
```

### 完成
再次发布新版本，查看日志，时间已经恢复正常，至此问题解决。
