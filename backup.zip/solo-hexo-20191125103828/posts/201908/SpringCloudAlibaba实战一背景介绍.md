title: Spring Cloud Alibaba 实战：（一、背景介绍）
date: '2019-08-14 00:15:37'
updated: '2019-08-14 08:51:54'
tags: [微服务, SpringCloud]
permalink: /articles/2019/08/14/1565712937025.html
---
![](https://img.hacpai.com/bing/20171225.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

```
一年前，Spring Cloud Alibaba 于 2018年7月27日 在 Spring Cloud 孵化器仓库提交第一次代码，而如
今，Spring Cloud Alibaba 完成了从 Spring Cloud 最默默无闻的项目到 Spring Cloud 最火项目的蜕变
，截至到 2019年8月1日 将近整整一年后，Spring Cloud Alibaba 从孵化器仓库毕业了！
```
随着 Spring Cloud Alibaba 从 Apache 孵化器仓库顺利毕业，这个 Spring 社区的首个国产开源项目越来越多的进入人们的视野，系列将记录本人在使用此产品过程中的完整经过，并附上主要代码，引领读者由浅入深，一步一步搭建出一套基于 Spring Cloud Alibaba 的微服务框架。

#### 1. 什么是 Spring Cloud Alibaba ?
* Spring Cloud Alibaba（简称SCA）和Spring Cloud Netflix（简称SCN）一样，都是Spring Cloud规范的一套实现。
#### 2. 为什么使用 Spring Cloud Alibaba ?
    
* 在SCA诞生前，绝大多数的 Spring Cloud 使用者，使用的都是SCN。

* Netflix公司首先宣布注册中心 Eureka 2.x 版本停止维护，随后又宣布限流组件 Hystrix 不再开放新功能。

* SCA中的组件，很多都是由阿里内部中间件转换而来，经历过多次双十一生产环境的考验，这也就意味着，SCA有着充足的场景，验证了他的高并发高可用的抗压能力。

* 在SCA诞生之后，由于阿里技术在开发者心中的影响力及公信力，加上各个组件优秀的设计和简单易用的API，SCA快速崛起，逐渐成为初代 Spring Cloud 使用者进行架构升级的第一方案。

* 对于绝大部分国内开发人员来说，SCA有着绝对的优势，那就是SCA的官方文档是中文的，这一优点对国内开发人员来说十分友好。

#### 3. Spring Cloud Alibaba 包含哪些功能 ?
* **服务限流降级：** 默认支持 Servlet、Feign、RestTemplate、Dubbo 和 RocketMQ 限流降级功能的接入，可以在运行时通过控制台实时修改限流降级规则，还支持查看限流降级 Metrics 监控。
* **服务注册与发现：** 适配 Spring Cloud 服务注册与发现标准，默认集成了 Ribbon 的支持。
* **分布式配置管理:** 支持分布式系统中的外部化配置，配置更改时自动刷新。
* **消息驱动能力：** 基于 Spring Cloud Stream 为微服务应用构建消息驱动能力。
* **分布式事务：** 使用 `@GlobalTransactional` 注解， 高效并且对业务零侵入地解决分布式事务问题。。
* **阿里云对象存储：** 阿里云提供的海量、安全、低成本、高可靠的云存储服务。支持在任何应用、任何时间、任何地点存储和访问任意类型的数据。
* **分布式任务调度：** 提供秒级、精准、高可靠、高可用的定时（基于 Cron 表达式）任务调度服务。同时提供分布式的任务执行模型，如网格任务。网格任务支持海量子任务均匀分配到所有 Worker（`schedulerx-client`）上执行。
* **阿里云短信服务：** 覆盖全球的短信服务，友好、高效、智能的互联化通讯能力，帮助企业迅速搭建客户触达通道。

#### 4. Spring Cloud Alibaba 毕业过程中的一些小插曲：
* 在 5 月底的时候，Spring Cloud Alibaba Team 跟 Spring Cloud Team 有过一次毕业的沟通，并且准备在 Spring Cloud Hoxton 正式发布的时候宣布 Spring Cloud Alibaba 毕业。只不过后来 Spring Cloud 官方调整了项目策略，需要进行仓库迁移。双方 team 后续还因此开了一个视频会议，Spring Cloud Alibaba 因此提前毕业。

* Spring Cloud Team 希望毕业后的 starter 命名方式跟 spring boot starter 规定的格式一致，以 alibaba-<X>-spring-cloud-starter 的格式进行命令。考虑到孵化器的 starter 都是以 spring-cloud-starter-alibaba-<X> 开头，Spring Cloud Alibaba 并不想破坏原有的规则。最终双方讨论了好多次才决定沿用老的 starter 命名方式。

* 在仓库迁移后的几天时间内，有社区的开源爱好者专门创建 issue 提问为何离开 spring cloud 仓库，Spring Cloud Alibaba 被各种质疑。后来 Spring Cloud Leader - Spencer Gibb 在 issue 上回复进行了解释。

* Spring Cloud Alibaba 本来计划是 6 月份发布毕业版本，结果拖到了现在。为了引起不必要的舆论风险，我们一直在等待 Spring Cloud Team 官方的公告发布，期间跟 Spring Cloud Team 沟通了好多个晚上(有 12 小时时差)。
#### 5. 毕业版本依赖关系
| Spring Cloud Version |  Spring Cloud Alibaba Version |  Spring Boot Version |
| --- |  --- |  --- |
| Spring Cloud Greenwich |  2.1.0.RELEASE |  2.1.X.RELEASE |
| Spring Cloud Finchley |  2.0.0.RELEASE |  2.0.X.RELEASE |
| Spring Cloud Edgware |  1.5.0.RELEASE |  1.5.X.RELEASE |


