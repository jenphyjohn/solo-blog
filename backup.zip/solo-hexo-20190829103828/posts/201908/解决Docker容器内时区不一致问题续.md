title: 解决Docker容器内时区不一致问题（续）
date: '2019-08-21 13:23:43'
updated: '2019-08-26 09:25:50'
tags: [docker, K8S]
permalink: /articles/2019/08/21/1566365023276.html
---
![](https://img.hacpai.com/bing/20180818.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 问题描述

[前文](http://blog.join-e.tech/articles/2019/08/17/1566055941127.html)我们通过修改Dockerfile修改了容器内的时区和时间，解决了Java应用内时差问题，然后Leader提出了一个新的问题，就是`FROM java:8
`基础镜像的体积太大了，整个镜像构建后大概有700MB ~ 800MB，这样当我们多个应用频繁发布版本的时候，服务器的磁盘空间也会变得吃紧，能否利用[alpine](http://blog.join-e.tech/articles/2019/08/22/1566458957268.html)制作一个基础镜像。

### 解决方案

首先想到的就是，Java应用的人这么多，是否已经有做好的基础镜像供大众使用，于是使用`docker search`命令查询关键字，得出以下结果：

![searchalpine.png](https://img.hacpai.com/file/2019/08/searchalpine-aea2b863.png)

可以看到，`docker.io/anapsix/alpine-java`镜像是以alpine为基础的，使用`Oracle Jave 8`并且集成了`GLIBC`等组件的基础镜像，stars数量为420，很符合我们的期待，又去 https://hub.docker.com/ 浏览了一下详细的介绍信息。好的，没毛病，就用它了。

### 方案落地

#### 操作记录：

1. 修改Dockerfile并启动

```
FROM anapsix/alpine-java
ADD target/Joine.jar /app.jar
EXPOSE 8080
ENTRYPOINT ["java","-jar","/app.jar"]
```
2. 查看指定容器日志
```
kubectl logs -f --tail=200 -n mynamespace mycontainername
```

3. 发现仍有时区问题，此处由于基础镜像不同，不能照搬之前的方式处理，继续优化Dockerfile
```
FROM anapsix/alpine-java
ENV TZ Asia/Shanghai
RUN echo "http://mirrors.aliyun.com/alpine/v3.4/main/" > /etc/apk/repositories \
        && apk --no-cache add tzdata zeromq \
        && ln -snf /usr/share/zoneinfo/${TZ} /etc/localtime \
        && echo "${TZ}" > /etc/timezone
ADD target/Joine.jar /app.jar
EXPOSE 8080
ENTRYPOINT ["java","-jar","/app.jar"]

```
4. 优化解释
alpine使用apk安装，这里先把apk安装源仓库更新为阿里云镜像仓库，之后进行apk安装tzdata时区工具，之后将工具时间和时区更新到系统

### 完成
再次发布新版本，查看日志，时间已经恢复正常，查看镜像大小，已缩减至200MB，很大程度上解决了之前镜像体积过大的问题。
