title: 实用SQL积累
date: '2019-08-13 13:24:48'
updated: '2019-10-25 18:41:22'
tags: [数据库, MySQL, SQL]
permalink: /articles/2019/08/13/1565673888156.html
---
![1557396540651.jpg](https://img.hacpai.com/file/2019/08/1557396540651-760f8b85.jpg)

### 工作中遇到的实用`SQL`, 积累起来放在这里, 以供需要时随时随地参考:

*目前仅记录MySQL数据库*

1. 查询数据库表名, 拼接修改字符集`SQL`

```
SELECT

CONCAT("ALTER TABLE `", TABLE_NAME,"` CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_bin;")

AS target_tables

FROM INFORMATION_SCHEMA.TABLES

WHERE TABLE_SCHEMA="db_name"

AND TABLE_TYPE="BASE TABLE"
```
---
2. 替换某个字段的部分字符串

```
UPDATE table_name 
SET column_name = REPLACE ( column_name, '替换之前字符串', '替换之后字符串' );
```

---
3. 更新另一张表某字段到表中

```
UPDATE tab1 
SET val = ( SELECT val FROM tab2 WHERE tab1.id = tab2.id ) 
WHERE
EXISTS ( SELECT 1 FROM tab2 WHERE tab1.id = tab2.id );
```

---
4. `待续...`


