title: GitFlow总结
date: '2019-11-21 17:27:48'
updated: '2019-11-24 21:48:10'
tags: [Git, 版本管理]
permalink: /articles/2019/11/21/1574328467849.html
---
：![](https://img.hacpai.com/bing/20180715.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 简介
GitFlow定义了一个项目发布的分支模型，为管理具有预定发布周期的大型项目提供了一个健壮的框架

## 分支介绍
- **master** 分支存放所有正式发布的版本，可以作为项目历史版本记录分支，不直接提交代码。仅用于保持一个对应线上运行代码的 code base
- **develop** 分支为主开发分支，一般不直接提交代码
- **feature** 分支为新功能分支，feature 分支都是基于 develop 创建的，开发完成后会合并到 develop 分支上，可以同时存在多个，命名为 feature-{name}
- **release** 分支基于最新 develop 分支创建，当新功能足够发布一个新版本（或者接近新版本发布的截止日期），从 develop 分支创建一个 release 分支作为新版本的起点，用于测试，所有的测试 bug 在这个分支改。测试完成后合并到 master 并打上 Tag （版本号），同时也合并到 develop 以更新最新开发分支。（一旦打了 release 分支之后不要从 develop 分支上合并新的改动到 release 分支），同一时间只有1个，生命周期很短，只是为了发布
- **hotfix** 分支基于 master 分支创建，对线上版本的 bug 进行修复，完成后直接合并到 master 分支和 develop 分支，如果当前还有新功能 release 分支，也同步到 release 分支上。同一时间只有1个，生命周期较短

![gitflow.jpeg](https://img.hacpai.com/file/2019/11/gitflow-f29d0a91.jpeg)

## 流程解析

1. 项目拥有者创建一个 develop 分支。可以本地创建一个空的 develop 分支，push到服务器上：
```shell
git branch –b develop
git push -u origin develop
```

2. 这个分支将会包含项目的全部历史，而 master 分支将只包含了部分历史。其它开发者这时应该克隆中央仓库，建好develop分支的跟踪分支：
```shell
git clone ssh://user@host/path/to/repo.git
git checkout -b develop origin/develop
```
3. 现在每个开发都有了这些历史分支的本地拷贝。从develop分支拉一个特性分支进行开发：
```shell
git checkout -b some-feature develop
git push(如果这个功能需要多个人协作，建议push)
```
4. 添加提交到各自功能分支上：编辑、暂存、提交：
```shell
git status
git add
git commit
git push(如果这个功能需要多个人协作)
```
5. 添加了提交后，如果团队使用Pull Requests，这时候可以发起一个请求用于合并到 develop 分支。否则就直接合并到本地的 develop 分支后push到中央仓库：
```shell
git pull origin develop
git checkout develop
git merge some-feature
git push
git branch -d some-feature
git push origin --delete some-feature (如果这个功能需要多个人协作) 
```
6. 然后用一个新的分支来做发布准备。这个分支是清理发布、执行所有测试、更新文档和其它为下个发布做准备操作的地方，像是一个专门用于改善发布的功能分支。只要创建这个分支并push到中央仓库，这个发布就是功能冻结的。任何不在 develop 分支中的新功能都推到下个发布循环中。这一步也确定了发布的版本号：
```shell
git checkout -b release-1.0.0 develop
```
7. 一旦准备好了对外发布，合并修改到 master 分支和 develop 分支上，删除发布分支：
```shell
git checkout master
git merge release-1.0.0
git push
git checkout develop
git merge release-1.0.0
git push
git branch -d release-1.0.0
git push origin --delete release-1.0.0
```
8. 发布分支是作为功能开发（develop分支）和对外发布（master分支）间的缓冲。只要有合并到 master 分支，就应该打好 Tag 以方便跟踪：
```shell
git tag -a 1.0.0 -m "Initial public release" master
git push --tags
```
9. 对外发布后，发现了当前版本的一个Bug，从 master 分支上拉出了一个 hotfix 分支，提交修改以解决问题，然后直接合并回 master 分支：
```shell
git checkout -b issue-#001 master
Fix the bug…..
git checkout master
git merge issue-#001
git push
```
10. 类似发布分支流程，hotfix 分支中的修改需要包含到 develop 分支中，然后才可以删除这个 hotfix 分支：
```shell
git checkout develop
git merge issue-#001
git push
git branch -d issue-#001
```
