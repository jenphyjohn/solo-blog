title: 实用Linux命令积累
date: '2019-09-16 10:08:17'
updated: '2019-09-16 10:08:17'
tags: [linux, cmd]
permalink: /articles/2019/09/16/1568599697398.html
---
![](https://img.hacpai.com/bing/20181201.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

* 写内容到文件中
```cmd
[root@master ~]# cat << EOF > filename
> line1
> line2
> line3
> ...
> EOF
```
* 复制vim编辑器内全部内容到剪贴板，可结合上条命令复制jar包内文件内容到新文件
```vim
gg"+yG
```
