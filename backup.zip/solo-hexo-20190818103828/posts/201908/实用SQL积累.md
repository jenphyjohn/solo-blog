title: 实用SQL积累
date: '2019-08-13 13:24:48'
updated: '2019-08-13 22:30:40'
tags: [数据库, MySQL, SQL]
permalink: /articles/2019/08/13/1565673888156.html
---
![1557396540651.jpg](https://img.hacpai.com/file/2019/08/1557396540651-760f8b85.jpg)

### 工作中遇到的实用`SQL`, 积累起来放在这里, 以供需要时随时随地参考:

*目前仅记录MySQL数据库*

1. 查询数据库表名, 拼接修改字符集`SQL`

```
SELECT

CONCAT("ALTER TABLE `", TABLE_NAME,"` CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_bin;")

AS target_tables

FROM INFORMATION_SCHEMA.TABLES

WHERE TABLE_SCHEMA="db_name"

AND TABLE_TYPE="BASE TABLE"
```
---
2. `待续...`


